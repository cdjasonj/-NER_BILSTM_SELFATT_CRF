from setuptools import setup

setup(
    name='hanzi_chaizi',
    version='0.1',
    packages=['hanzi_chaizi'],
    url='',
    license='',
    author='Xiaoquan Kong',
    author_email='u1mail2me@gmail.com',
    description='',
    include_package_data=True
)
